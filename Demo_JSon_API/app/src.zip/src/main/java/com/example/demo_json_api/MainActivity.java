package com.example.demo_json_api;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

List<NyModel> nysList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String json = "[{\"_id\":\"649c619906717d6cef3ff9f1\",\"name\":\"Nguyễn Thị A\",\"phone\":\"0123456789\",\"description\":\"Xinh gái ngời ngời, giỏi giang, bố làm to\",\"type\":{\"_id\":\"649c5fff78469416d92c724c\",\"name\":\"sexy\",\"description\":\"Hotgirl 3 vòng đồng hồ cát\"}}]";


        new Thread(new Runnable() {
            @Override
            public void run() {
                testApi();
            }
        }).start();

    }

    private void testApi() {
        try {
            URL url = new URL("http://10.82.1.154:3000/nyManager/list-ny");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set the request method to POST
            connection.setRequestMethod("GET");
//            connection.setRequestProperty("Content-Type", "application/json");
//            connection.setDoOutput(true);

            // Write the request body
//            OutputStream outputStream = connection.getOutputStream();
//            String requestBody = "{\"email\": \"eve.holt@reqres.in\", \"password\": \"cityslicka\" }";
//            outputStream.write(requestBody.getBytes());
//            outputStream.flush();
//            outputStream.close();

            // Get the response
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                StringBuilder response = new StringBuilder();

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();

                String json = response.toString();
                JSONArray array = new JSONArray(json);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    NyModel ny = new NyModel();

                    ny._id = obj.getString("_id");
                    ny.name = obj.getString("name");
                    ny.phone = obj.getString("phone");
                    ny.description = obj.getString("description");

                    JSONObject objType = obj.getJSONObject("type");
                    Type nyType = new Type();
                    nyType._id = objType.getString("_id");
                    nyType.name = objType.getString("name");
                    nyType.description = objType.getString("description");

                    ny.type = nyType;
                    MainActivity.this.nysList.add(ny);
                }

                // Process the response
                System.out.println("Thinhnt Response: " + nysList.toString());
            } else {
                System.out.println("Request failed with response code: " + responseCode);
            }

            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}

class NyModel {
    public String _id;
    public String name;
    public String phone;
    public String description;
    public Type type;
}

class Type {
    public String _id;
    public String name;
    public String description;
}